package frc.Autonomous.Actions;

// this will probably be deleted because CatzRobotTracker already uses vision
public class VisionAlignmentAction implements ActionBase{
    /*
     * will we need to make it?
     */

    @Override
    public void init() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public boolean isFinished() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void update() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void end() {
        // TODO Auto-generated method stub
        
    }
}