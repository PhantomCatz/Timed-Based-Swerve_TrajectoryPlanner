package frc.Autonomous.Actions;

import java.util.function.Function;

import edu.wpi.first.math.controller.HolonomicDriveController;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.math.trajectory.Trajectory;
import edu.wpi.first.wpilibj.Timer;
import frc.Autonomous.CatzRobotTracker;
import frc.Mechanisms.CatzDrivetrain;
import frc.robot.CatzConstants;

// Follows a trajectory
public class TrajectoryFollowingAction implements ActionBase{

    private final Timer timer = new Timer();
    private final HolonomicDriveController controller;
    private final CatzRobotTracker robotTracker = CatzRobotTracker.getInstance();
    private final CatzDrivetrain driveTrain = CatzDrivetrain.getInstance();

    private final Trajectory trajectory;
    private final Function<Pose2d, Rotation2d> refHeading;

    /**
     * @param trajectory The trajectory to follow
     * @param refHeading The goal heading for the robot to be in while in the middle of the trajectory. Takes a Pose2d parameter so that the heading may change based on external factors. 
     */
    public TrajectoryFollowingAction(Trajectory trajectory, Function<Pose2d,Rotation2d> refHeading)
    {
        this.trajectory = trajectory;
        this.refHeading = refHeading; // this returns the desired orientation when given the current position (the function itself is given as an argument). But most of the times, it will just give a constant desired orientation.
        // also, why is it called refheading? wouldn't something like targetOrientation be better

        controller = CatzConstants.holonomicDriveController; // see catzconstants
    }

    // reset and start timer
    @Override
    public void init() {
        timer.reset();
        timer.start();
    }

    // calculates if trajectory is finished
    @Override
    public boolean isFinished() {
        return timer.hasElapsed(trajectory.getTotalTimeSeconds()); //will only work if the code is configured correctly.
    }

    // sets swerve modules to their target states so that the robot will follow the trajectory
    // see catzconstants
    @Override
    public void update() {
        double currentTime = timer.get();
        Trajectory.State goal = trajectory.sample(currentTime);
        
        System.out.println("current " + robotTracker.getEstimatedPosition().getX() + " " + robotTracker.getEstimatedPosition().getY());
        
        ChassisSpeeds adjustedSpeed = controller.calculate(robotTracker.getEstimatedPosition(), goal, refHeading.apply(robotTracker.getEstimatedPosition()));
        SwerveModuleState[] targetModuleStates = CatzConstants.swerveDriveKinematics.toSwerveModuleStates(adjustedSpeed);
        
        System.out.println("goal " + adjustedSpeed.vxMetersPerSecond + " " + adjustedSpeed.vxMetersPerSecond);

        driveTrain.setSwerveModuleStates(targetModuleStates);
    }

    // stop all robot motion
    @Override
    public void end() {
        timer.stop();

        ChassisSpeeds nullChassisSpeeds = new ChassisSpeeds(0, 0, 0);
        SwerveModuleState[] nullModuleStates = CatzConstants.swerveDriveKinematics.toSwerveModuleStates(nullChassisSpeeds);

        driveTrain.setSwerveModuleStates(nullModuleStates);
    }
}