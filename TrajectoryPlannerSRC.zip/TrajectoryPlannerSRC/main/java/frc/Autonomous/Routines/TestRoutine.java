package frc.Autonomous.Routines;

import java.util.List;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj.Timer;
import frc.Autonomous.Actions.*;
import frc.Autonomous.Paths.Trajectories;

public class TestRoutine extends AutonRoutineBase{
    @Override
    protected void routine() {
        runAction(new TrajectoryFollowingAction(Trajectories.testTrajectory, (p) -> Rotation2d.fromDegrees(0))); //follow the test trajectory while turning towards 180 degrees.

        // this can be replaced with System.out.println("yay") but is here to test runAction and VoidAction
        runAction(new VoidAction(()->System.out.println("yay")));

        runAction(new ParallelAction(List.of(
            new VoidAction(()->System.out.println("paral")),
            new VoidAction(()->System.out.println("paral"))
        )));
    }
}