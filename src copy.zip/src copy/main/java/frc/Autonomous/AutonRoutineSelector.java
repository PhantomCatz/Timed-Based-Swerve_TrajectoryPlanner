package frc.Autonomous;

import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import frc.Autonomous.Routines.AutonRoutineBase;
import frc.Autonomous.Routines.*;

public class AutonRoutineSelector {
    private static AutonRoutineSelector instance = null;


    enum Routine
    {
        DO_NOTHING(new DoNothingRoutine()),
        TEST(new TestRoutine());

        public AutonRoutineBase routine;

        private Routine(AutonRoutineBase routine)
        {
            this.routine = routine;
        }
    }

    private Routine selectedRoutine = Routine.DO_NOTHING;

    private SendableChooser<Routine> routineChooser;

    private final AutonActionExecutor autonActionExecutor = AutonActionExecutor.getInstance();

    private AutonRoutineSelector()
    {
        routineChooser = new SendableChooser<>();

        for(Routine routine : Routine.values()){
            routineChooser.addOption(routine.name(), routine);
        }
    }

    public void updateSelectedRoutine()
    {
        Routine routine = routineChooser.getSelected();

        if(routine == null)
        {
            selectedRoutine = Routine.DO_NOTHING;
        }
        else
        {
            selectedRoutine = routine;
        }

        autonActionExecutor.setAutonMode(selectedRoutine.routine);

        System.out.println("Selected routine: " + selectedRoutine.name());
    }


    public static AutonRoutineSelector getInstance()
    {
        if(instance == null)
        {
            instance = new AutonRoutineSelector();
        }
        return instance;
    }
}
