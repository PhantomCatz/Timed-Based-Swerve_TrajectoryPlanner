package frc.Autonomous;

import frc.Autonomous.Routines.AutonRoutineBase;

public class AutonActionExecutor {
    private AutonRoutineBase routine = null;
    private Thread thread = null;

    private static AutonActionExecutor instance = null;

    public void setAutonMode(AutonRoutineBase newRoutine)
    {
        this.routine = newRoutine;

        thread = new Thread(()->{
            if(routine != null)
            {
                routine.runAuton();
            }
        });
    }

    public void start()
    {
        if(thread != null)
        {
            thread.start();
        }
        else
        {
            System.out.println("You forgot to set up the thread");
        }
    }

    public void stop()
    {
        if(routine != null)
        {
            routine.stop();
        }
        thread = null;
    }

    public static AutonActionExecutor getInstance()
    {
        if(instance == null)
        {
            instance = new AutonActionExecutor();
        }
        return instance;
    }

    public static void resetInstance()
    {
        if(instance != null)
        {
            instance = new AutonActionExecutor();
        }
    }
}
