package frc.Autonomous.Actions;

import java.util.function.Function;

import edu.wpi.first.math.controller.HolonomicDriveController;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.math.trajectory.Trajectory;
import edu.wpi.first.wpilibj.Timer;
import frc.Autonomous.CatzRobotTracker;
import frc.Mechanisms.CatzDrivetrain;
import frc.robot.CatzConstants;

public class TrajectoryFollowingAction implements ActionBase{

    private final Timer timer = new Timer();
    private final HolonomicDriveController controller;
    private final CatzRobotTracker robotTracker = CatzRobotTracker.getInstance();
    private final CatzDrivetrain driveTrain = CatzDrivetrain.getInstance();

    private final Trajectory trajectory;
    private final Function<Pose2d, Rotation2d> refHeading;

    /**
     * @param trajectory The trajectory to follow
     * @param refHeading The goal heading for the robot to be in while in the middle of the trajectory. Takes a Pose2d parameter so that the heading may change based on external factors. 
     */
    public TrajectoryFollowingAction(Trajectory trajectory, Function<Pose2d,Rotation2d> refHeading)
    {
        this.trajectory = trajectory;
        this.refHeading = refHeading;

        controller = CatzConstants.holonomicDriveController;
    }

    @Override
    public void init() {
        timer.reset();
        timer.start();
    }

    @Override
    public boolean isFinished() {
        return timer.hasElapsed(trajectory.getTotalTimeSeconds());
    }

    @Override
    public void update() {
        double currentTime = timer.get();
        Trajectory.State goal = trajectory.sample(currentTime);
        
        ChassisSpeeds adjustedSpeed = controller.calculate(robotTracker.getEstimatedPosition(), goal, refHeading.apply(robotTracker.getEstimatedPosition()));
        SwerveModuleState[] targetModuleStates = CatzConstants.swerveDriveKinematics.toSwerveModuleStates(adjustedSpeed);

        driveTrain.setSwerveModuleStates(targetModuleStates);
    }

    @Override
    public void end() {
        timer.stop();

        ChassisSpeeds nullChassisSpeeds = new ChassisSpeeds(0, 0, 0);
        SwerveModuleState[] nullModuleStates = CatzConstants.swerveDriveKinematics.toSwerveModuleStates(nullChassisSpeeds);

        driveTrain.setSwerveModuleStates(nullModuleStates);
    }
    
}
