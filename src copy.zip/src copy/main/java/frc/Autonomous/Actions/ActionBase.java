package frc.Autonomous.Actions;

public interface ActionBase {
    public void init();

    public boolean isFinished();

    public void update();

    public void end();
}
