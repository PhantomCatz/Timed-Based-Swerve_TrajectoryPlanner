package frc.Autonomous.Routines;

import frc.Autonomous.Actions.ActionBase;

public abstract class AutonRoutineBase {
    protected abstract void routine();

    private boolean isActive = false;
    private final int threadPeriodMS = 20;

    public void runAuton()
    {
        isActive = true;

        routine(); 
    }

    public void runAction(ActionBase action)
    {
        action.init();

        while(isActive && !action.isFinished())
        {
            action.update();

            try
            {
                Thread.sleep(threadPeriodMS);
            }
            catch(InterruptedException e){}
        }

        action.end();
    }

    public final void stop()
    {
        isActive = false;
    }
}
