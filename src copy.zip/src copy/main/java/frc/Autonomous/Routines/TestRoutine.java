package frc.Autonomous.Routines;

import edu.wpi.first.math.geometry.Rotation2d;
import frc.Autonomous.Actions.TrajectoryFollowingAction;
import frc.Autonomous.Actions.VoidAction;
import frc.Autonomous.Paths.Trajectories;

public class TestRoutine extends AutonRoutineBase{

    @Override
    protected void routine() {
        runAction(new TrajectoryFollowingAction(Trajectories.testTrajectory, (p) -> Rotation2d.fromDegrees(180)));

        runAction(new VoidAction(()->System.out.println("yay")));
    }
    
}
