package frc.Autonomous.Routines;

public class DoNothingRoutine extends AutonRoutineBase{
    // this does nothing

    @Override
    protected void routine() {
        System.out.println("doing nothing");
    }
}