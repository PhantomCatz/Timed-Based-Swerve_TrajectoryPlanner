package frc.Autonomous.Routines;

import java.util.List;

import edu.wpi.first.math.geometry.Rotation2d;
import frc.Autonomous.Actions.TrajectoryFollowingAction;
import frc.Autonomous.Actions.VoidAction;
import frc.Autonomous.Paths.Trajectories;

public class TestRoutine extends AutonRoutineBase{
    @Override
    protected void routine() {
        runAction(new TrajectoryFollowingAction(Trajectories.testTrajectory, (p) -> Rotation2d.fromDegrees(180))); //follow the test trajectory while turning towards 180 degrees.

        // this can be replaced with System.out.println("yay") but is here to test runAction and VoidAction
        runAction(new VoidAction(()->System.out.println("yay")));

        runAction(new ParallelAction(List.of(
            new VoidAction(()->System.out.println("dance")),
            
        )));
    }
}