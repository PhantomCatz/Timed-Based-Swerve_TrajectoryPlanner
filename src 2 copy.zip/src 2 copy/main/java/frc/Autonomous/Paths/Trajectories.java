package frc.Autonomous.Paths;

import java.util.List;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.trajectory.Trajectory;
import edu.wpi.first.math.trajectory.TrajectoryConfig;
import edu.wpi.first.math.trajectory.TrajectoryGenerator;

public class Trajectories {
    //all the trajectories will be created here

    public static final Trajectory testTrajectory = generateTrajectory(
        new Pose2d(0, 0, Rotation2d.fromDegrees(0)),  //starting point
        List.of(
            new Translation2d(1, 0)                   //any point inbetween start and end so a curve can be created.
        ),
        new Pose2d(3, 0, Rotation2d.fromDegrees(180)),//ending point
        2.0, 1.0
    );

    // generates trajectory
    private static Trajectory generateTrajectory(Pose2d startPos, List<Translation2d> waypoints, Pose2d endPos, double maxVel, double maxAccel)
    {
        return TrajectoryGenerator.generateTrajectory(startPos, waypoints, endPos, new TrajectoryConfig(maxVel, maxAccel));
    }
}
